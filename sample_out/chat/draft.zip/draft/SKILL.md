---
name: draft
description: >-
  Specification refinement mode for fleet-generator. Uses artifacts for markdown drafts and HTML/SVG mockups. Read-only on filesystem. Use when user types /draft or says draft mode, refine the spec, write the mission, draft it, polish it.
when_to_use: >-
  User says /draft, draft mode, refine the spec, write the mission. Not for general writing requests.
status: active
tags: [skill]
updated: 2026-11-12
---

# /draft — Specification Refinement Mode

You write and refine the mission in artifacts. You may read files; you
write none. The mission reaches the repo through /submit and the
worker, so a draft written straight to disk would skip the human's
approval.

## On entry

1. Call `memory_user_edits` and replace the ACTIVE MODE line:

```
ACTIVE MODE: DRAFT — Refining a mission. Artifacts for the draft
and mockups. Read-only on the filesystem. Store the draft in
Workspace. End each response with [MODE: DRAFT].
```

2. Read the Workspace artifact's `window.storage` for the findings from
   /scope. If there are none, ask the human what the mission is for.

3. Read [references/mission-template.md](references/mission-template.md)
   for the required format.

## What needs nobody's go-ahead

Reading any file in the project's repos; creating and revising the
markdown draft, HTML or SVG mockups and diagrams, and the Workspace
artifact; reading the reference files bundled with this skill.

## What waits for another mode

- Writing to any filesystem location, or pushing: /submit and the
  worker do that
- Scoping new work: /scope

## Drafting

1. Load the scope findings from the Workspace's `window.storage`.
2. Read [references/mission-template.md](references/mission-template.md),
   [references/mission-scoping.md](references/mission-scoping.md) for the
   tier, and [references/blast-radius.md](references/blast-radius.md) for
   the scope declaration.
3. Check every path and file:line anchor you put in the draft against the
   file itself, not against the scope notes: a moved anchor sends the
   worker somewhere wrong with total confidence.
4. Write the whole draft in one markdown artifact, then present it. Do
   not hand it over section by section.
5. Revise as the human comments, until they approve.
6. Store the final text in Workspace under `draft-mission-content`.

## Before you call it ready

Write each check with its result in your reply:

- [ ] Every required section present (see the mission-template reference)
- [ ] No placeholders (TODO, FILL, TBD, XXX)
- [ ] Blast radius declared if the mission touches existing code
- [ ] Every file in "Files to Modify" appears in a Part
- [ ] Each Part has a commit message, and each Part but the last a
      `→ verify:` line
- [ ] Tier cap respected, or the atomic exception justified

When approved: "Draft stored. Say /submit to prepare for launch."

End each response with [MODE: DRAFT].
