---
name: draft
description: >-
  Specification refinement mode for fleet-generator. Uses artifacts for markdown drafts and HTML/SVG mockups. Read-only on filesystem. Use when user types /draft or says draft mode, refine the spec, write the mission, draft it, polish it.
when_to_use: >-
  User says /draft, draft mode, refine the spec, write the mission. Do NOT trigger on general writing requests.
status: active
tags: [skill]
updated: 2026-05-07
---

# /draft — Specification Refinement Mode

> **READ-ONLY ON FILESYSTEM.** You may read files. You may NOT
> write files. All output goes into artifacts in the conversation.

## On Entry

1. Call `memory_user_edits` — replace ACTIVE MODE line:

```
ACTIVE MODE: DRAFT — Refining a spec. Use artifacts for
markdown and mockups. Read-only on filesystem. Store draft in
Workspace. Do NOT submit or write to filesystem. End every
response with [MODE: DRAFT].
```

2. Read the Workspace artifact's `window.storage` for scope
   findings from /scope mode. If none exist, ask the human for
   direction.

3. Read [references/mission-template.md](references/mission-template.md)
   for the required format.

4. Acknowledge: "draft mode. Refining the spec."

## What you CAN do

- Read files (filesystem or GitHub)
- Create and update artifacts:
  - **Markdown** for the mission file draft
  - **HTML/SVG** for mockups, diagrams
  - **Workspace** for persistent state
- Iterate with the human: they comment, you revise
- Read reference files bundled with this skill

## What you CANNOT do

- Write files to any filesystem location
- Submit (say /submit)
- Push to git
- Scope new work (say /scope)

## Drafting workflow

1. Load scope findings from workspace `window.storage`
2. Read [references/mission-template.md](references/mission-template.md)
3. Read [references/mission-scoping.md](references/mission-scoping.md)
   for tier classification
4. Read [references/blast-radius.md](references/blast-radius.md)
   for scope declaration rules
5. Create a markdown artifact with the mission file draft
6. Present to the human; iterate until approved
7. Store final content in workspace under key `draft-mission-content`

## Validation before handoff

Before telling the human the draft is ready, verify:

- [ ] All required sections present (see mission-template reference)
- [ ] No placeholders (TODO, FILL, TBD, XXX)
- [ ] Blast radius declared if touching existing code
- [ ] Every file in "Files to Modify" appears in a Part
- [ ] Each Part has commit message and `→ verify:` line
- [ ] Tier cap respected (or atomic exception justified)

When approved: "Draft stored. Say /submit to prepare for launch."

End EVERY response with: [MODE: DRAFT]
