# Mission Template — Required Format (for /draft)

```markdown
# Mission: [Title]

## Context
<2–4 short paragraphs — why this work, what outcome>

## Read First (optional)
- relevant docs / files

## Blast Radius Scope (if touching existing code)
**Symbols being changed:** ...

## Files to Modify
| File | Change |
|---|---|
| ... | ... |

## Files NOT to Modify
- ...

## Implementation Parts

### Part 1 — [description]
[instructions]

**Commit:** `type(scope): description`
→ verify: [what to check]

### Part 2 — [description]
...

## Test Requirements
- ...

## Verification
- ...

## Success Criteria
- [ ] ...
```

## Per-Part rules

- Each Part = one logical change = one commit
- Every Part except the last has a `→ verify:` line
- Last Part uses `## Verification` instead

## What the mission does NOT contain

- Standard skill list
- Worker execution order
- Agent definitions
- Control-plane metadata
