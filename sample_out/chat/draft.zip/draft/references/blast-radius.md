# Blast Radius Declaration (for /draft)

When the mission touches existing code, the draft must include a
Blast Radius Scope section.

```markdown
## Blast Radius Scope

**Symbols being changed:**
- `SymbolName` — change type (rename / removal / signature / semantic)

**Expected blast radius (estimate):**
- Production code: ~N sites across <list>
- Tests: ~N files
- Docs: <list>
```

The estimate is a target. The worker runs the `blast-radius` skill
to produce the authoritative report and surfaces RESCOPE_REQUIRED if
the actual blast exceeds the estimate.

For purely additive missions, omit this section and state
"All-new files. No edits to existing code." in Context.
