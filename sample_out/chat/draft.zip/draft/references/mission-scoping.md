# Tier Caps (for /draft)

## Tier 1: primitive-touching — ≤ 3 edits

Strict cap. If at the cap and a 4th file is needed, RESCOPE.

## Tier 2: UI-bounded — ≤ 6 files

Must NAME the bounding component.

## Tier 3: net-new — no cap

Only adds new files. State explicitly: "all-new files, no edits to
existing code."

## Atomic exception

Cross-layer change that cannot be split without breaking the
integration branch. Requires `Atomic justification:` line.

If none of the four fits, split the mission.
