---
name: memory-interface
description: >-
  Operating guide for the team's persistent memory backend (fleet-generator's NexusMCP) — semantic search, knowledge graph, diary, query construction, filesystem-vs-memory precedence.
when_to_use: >-
  Searching memory for prior decisions, patterns, or context. Composing a memory search query. Adding or invalidating KG facts. Choosing between memory and filesystem as ground truth. Recovering when memory is down. Trigger phrases: query the palace, query memory, semantic search, knowledge graph, KG fact, diary entry, AAAK, drawer, wing, filesystem wins, memory backend.
status: active
tags: [skill]
updated: 2026-05-07
---

> **PREVIEW — NexusMCP launches soon.** This skill describes how the
> agent uses NexusMCP for cross-session memory. The MCP server is not
> yet available; calls silently no-op until it ships. No regeneration
> is needed when NexusMCP lands — the skill body is already complete.

# Memory Interface

The persistent memory backend is the team's working memory across
conversations. It indexes content from the project's documents and
exposes semantic search, a typed knowledge graph, and a diary log.

This skill documents the interface — what tools to call, how to query,
when to update, and how to handle outages.

## What memory is

A vector database indexing **drawers** (verbatim text atoms extracted
from source files) organized into **rooms** (logical groupings) within
**wings** (top-level scopes — typically one per repo or doc set).

Search is semantic: queries return drawers ranked by similarity to
the query embedding.

A separate **knowledge graph** stores typed facts (subject → predicate
→ object) with temporal validity.

A separate **diary** stores narrative session summaries.

## Five core operations

### Status check
Confirm memory is alive. Returns wing list, drawer counts, current
protocol. Call at session start.

### Search
Semantic search over drawers. Returns verbatim content with similarity
scores.

### List wings
Returns wings currently mined and their drawer counts. Use when you
don't remember which wings exist.

### KG operations
- **Query** an entity's relationships
- **Add** a new fact (subject, predicate, object, reason)
- **Invalidate** an expired fact
- **Timeline** facts about an entity in chronological order

### Diary operations
- **Read** recent entries (use a topic tag to filter)
- **Write** a session summary (topic + entry text)

## How to query well

The most common failure is constructing the query like a natural-
language question. Don't.

**Good queries:**
- `mission template required sections`
- `auth flow password reset`
- `schema migration foreign key`

**Bad queries:**
- "What is the mission template's required structure?" (too long,
  function words dilute the embedding)
- "auth" (too short, returns everything auth-related)
- "tell me about migrations" (imperative phrasing wastes embedding
  budget)

**When a query returns thin results:**
1. Try different keywords — memory indexes the source text, not
   synonyms
2. Drop the wing filter and try unfiltered
3. Increase `limit` — sometimes the right drawer is at rank 6
4. Read the actual file directly. Memory is a search index, not a
   substitute for reading.

## Filesystem-vs-memory precedence

When memory disagrees with current filesystem state, **the filesystem
wins.** Memory lags reality by however long it's been since the last
re-mine. After significant doc edits, expect memory to reflect the
pre-edit state until re-indexed.

- **Use memory** for context, prior decisions, established patterns
- **Use the filesystem** for current state, recent changes, anything
  authoritative for ongoing work

If a decision depends on a "current state" claim, verify against the
filesystem before acting. Memory is for orientation, not authority.

## When to update memory

- Major doc reorganization (file moves, deletions, renames)
- After landing a doctrine doc (so future searches find it)
- After a significant cleanup
- Periodic refresh

Re-mining is not free — full re-mine can take 30+ minutes. Don't
trigger casually.

## When memory is down

If status check fails:
1. Note it briefly to the human
2. Fall back to direct file reads / grep
3. Don't let memory loss block real work

The session continues without semantic search; agents have to grep
everything by hand. Worth fixing fast, but not session-blocking.
