---
name: continuity
description: >-
  Auxiliary cross-session continuity for fleet-generator — externalize state at boundaries so a fresh chat can pick up where this one left off. Gracefully degrades when no memory backend is connected.
when_to_use: >-
  Context is getting full. Bob says checkpoint or package a handoff. Phase complete, decision landed, debug resolved. Switching chats. Before a risky operation. Trigger phrases: continuity protocol, the context is getting full, checkpoint, package a handoff, prepare to switch chats, HANDOFF PACKET, externalize state, paste blob, resumption guidance.
status: active
tags: [skill]
updated: 2026-05-07
---

# Continuity — Cross-Session Handoff

> **AUXILIARY.** When a memory backend (NexusMCP, mempalace, similar)
> is connected, write state there. When nothing is connected, fall
> back to a paste-able HANDOFF PACKET artifact. Do not complain about
> a missing backend — just take the available path.

## When to externalize

- Natural milestone: phase complete, decision landed, debug resolved
- Context pressure: conversation getting long, compaction likely
- Human asks: "checkpoint this" / "package a handoff"
- Before a risky operation

## What to write (memory backend present)

### Knowledge graph
- Decisions made (subject → predicate → object, with reason)
- Status changes (phase complete, tool working/broken)
- Relationships established

### Diary / narrative log
- Session milestone summaries
- Shape of what happened, resumption guidance for the next session
- Topic tag for future search

### Invalidate stale facts
- At the moment a fact stops being true, not later

## What to write (no memory backend)

Produce a **HANDOFF PACKET** artifact the human can paste into a
fresh chat. Format:

```markdown
# Handoff — <topic> — <ISO date>

## Where we are
- Project: fleet-generator
- Branch / file area: <path>
- Last commit / state: <hash or summary>

## What was decided
- <decision 1, with reason>
- <decision 2, with reason>

## What is unresolved
- <open question 1>
- <open question 2>

## What the next session does first
1. <first action>
2. <second action>

## Anchors
- Files to re-read: <paths>
- Commands to re-run: <commands>
```

## When NOT to externalize

- Routine tool calls with no new state
- Read-only investigation confirming known facts
- Casual conversation without decisions

## Within-conversation state

The Workspace artifact (from /scope and /draft modes) carries
within-conversation state across compaction. Continuity is for
*cross*-conversation persistence — valuable when available, not
required.
