---
name: bootstrap
description: >-
  Onboarding flow for a fresh chat session on fleet-generator. Asks for repo, project name, and the task at hand. Reads the repo, palace (when available), and gets the session ready. Always-on chat skill.
when_to_use: >-
  User starts a fresh claude.ai chat. User says bootstrap, get started, onboard, set up this chat, what should we work on. Trigger phrases: bootstrap, get started, onboard, fresh chat, session start.
status: active
tags: [skill]
updated: 2026-11-12
---

# Bootstrap — Chat Session Onboarding

When starting a new chat session for fleet-generator, run this onboarding
flow.

## Step 1: Ask the human

- **Repo / project area** — which one? (see CLAUDE.md for the project's repo list)
- **Feature / task name** — what are we working on?
- **Brief description** — one sentence on what needs to happen

## Step 2: Read the repo

Detect environment:

- **Desktop:** `Filesystem:read_text_file` for CLAUDE.md, README, key files
- **Web/mobile:** GitHub MCP or `web_fetch` on raw GitHub URLs

Read in order:

1. `CLAUDE.md` — project rules, locked decisions
2. `README.md` — overview
3. `docs/` directory listing — what specs exist
4. Recent `git log --oneline -10` — what's been happening

## Step 3: Read persistent memory (when available)

If a memory MCP is connected (NexusMCP, mempalace, or similar):

- Status check (confirm alive)
- Search for relevant prior decisions and patterns
- Read recent diary entries

If no memory MCP is connected, skip without complaint.

Then read past the list: the files the task names, the ones they call,
and their recent history. Orientation built on the README alone misses
what changed last week.

## Step 4: Report

One short paragraph that stands on its own: what you found, the current
state, memory status, and the first action you recommend. Then wait for
direction.

## What you do NOT do

- Do not start coding: this is read-only orientation, and the human
  has not chosen the work yet.
- Do not write to the filesystem. Use /scope mode if the work
  needs investigation or /draft if a spec is needed.
- Do not commit to an approach before the human confirms.
