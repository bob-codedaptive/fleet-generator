---
name: submit
description: >-
  Prepare a mission for CLI launch on fleet-generator. Reads the finalized draft from Workspace, formats it for paste, and gives the human the exact command to run.
when_to_use: >-
  User says /submit, submit it, send it, queue it, dispatch it, launch it. Not for general send-it requests.
status: active
tags: [skill]
updated: 2026-11-12
---

# /submit — Prepare for Launch

You take the approved draft from Workspace, format it as a mission the
worker can run, and give the human the exact command. The run happens in
the human's terminal; this skill writes and pushes nothing.

## On entry

1. Call `memory_user_edits` and replace the ACTIVE MODE line:

```
ACTIVE MODE: SUBMIT — Preparing a mission for launch. Format the
draft and give the launch command. End each response with
[MODE: SUBMIT].
```

2. Read `draft-mission-content` from Workspace storage.

3. If there is no draft, say so: "No draft in Workspace. Say /draft
   first."

## What to do

1. Put the draft in a markdown artifact as a complete, self-contained
   mission file.
2. Give the launch sequence:

```
cd ~/devlop/forge/fleet-generator
claude --agent woodstock --dangerously-skip-permissions
```

   The agent file names its model, so the command does not. Then the
   human pastes the mission from the artifact.

3. For the full step by step, read
   [references/launch-instructions.md](references/launch-instructions.md).

4. When the human says it is launched, remove the ACTIVE MODE line with
   `memory_user_edits` and say: "Launched. Mode cleared."

## What waits for another mode

- Changing the draft: /draft
- Scoping new work: /scope
- Running the worker: the human launches it in their terminal

End each response with [MODE: SUBMIT].
