---
name: submit
description: >-
  Prepare a mission for CLI launch on fleet-generator. Reads the finalized draft from Workspace, formats it for paste, and gives the human the exact command to run.
when_to_use: >-
  User says /submit, submit it, send it, queue it, dispatch it, launch it. Do NOT trigger on general send-it requests.
status: active
tags: [skill]
updated: 2026-05-07
---

# /submit — Prepare for Launch

> Reads the finalized draft from Workspace. Formats it. Hands the
> human the exact CLI command to launch the worker. The actual run
> happens in the human's terminal — this skill does not push.

## On Entry

1. Call `memory_user_edits` — replace ACTIVE MODE line:

```
ACTIVE MODE: SUBMIT — Preparing mission for launch. Format
the draft and present launch instructions. End every response
with [MODE: SUBMIT].
```

2. Read Workspace storage:
   - `draft-mission-content` (the finalized mission markdown)

3. If no draft content, tell the human: "No draft in workspace.
   Say /draft first."

## What to do

1. Format the draft as a complete, self-contained mission file in a
   markdown artifact.
2. Tell the human the launch sequence:

```
cd ~/devlop/forge/fleet-generator
claude --agent woodstock --model opus --dangerously-skip-permissions
```

Then paste the mission content from the artifact.

3. Read [references/launch-instructions.md](references/launch-instructions.md)
   for the full step-by-step.

4. After confirming the human has launched, clear ACTIVE MODE:

```
memory_user_edits: remove the ACTIVE MODE line
```

Tell the human: "Launched. Mode cleared."

## What you CANNOT do

- Edit the draft (say /draft)
- Scope new work (say /scope)
- Run the worker for the human (the human launches in their terminal)

End EVERY response with: [MODE: SUBMIT]
