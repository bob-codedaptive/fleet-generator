# Launch Instructions (for /submit)

## What the human does

1. Open a terminal and go to the repo:

```
cd ~/devlop/forge/fleet-generator
```

2. Launch the worker:

```
claude --agent woodstock --dangerously-skip-permissions
```

3. Paste the mission from the artifact and press return.

## What the worker does

- Starts Snoopy for pre-flight, and stops on a RED
- Implements Part by Part, with a check and a commit for each
- Runs the tests once, at the end, and pastes the output
- Runs `self-review`, then starts Marvin for post-flight review
- Fixes what a FAIL names and resumes the same reviewer, at most three
  times, then reports
- Starts the specialists whose triggers fired

The worker starts the reviewer itself. Read its verdict in the worker's
final report, or read `git log` and `git diff` yourself.

## What goes wrong, and why

- **The worker stops early**: usually a missing or unclear instruction
  in the mission. Reopen /draft, fix it, and /submit again.
- **Pre-flight returns RED**: the mission's premise or file list does
  not match the code. The report says where; fix the mission.
- **The baseline tests fail**: they must pass before the mission starts.
  Fix that in a separate mission.
- **Scope creep**: the worker touched files not listed. Marvin catches
  it. Expand the mission through /draft, or revert the extra changes.
