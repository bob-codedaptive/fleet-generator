# Launch Instructions (for /submit)

## What the human does

1. Open Terminal
2. Navigate to the repo:

```
cd ~/devlop/forge/fleet-generator
```

3. Launch the worker:

```
claude --agent woodstock --model opus --dangerously-skip-permissions
```

4. Paste the mission content from the artifact and hit return.

5. Watch the worker execute. The worker will:
   - Read the mission
   - Run the blast-radius pre-flight if needed
   - Implement Part by Part, committing as it goes
   - Run `pre-commit` before each commit
   - Run `self-review` before declaring done

## What goes wrong, and why

- **Worker exits early** — usually a missing or unclear instruction
  in the mission. Re-open /draft, fix the ambiguity, /submit again.
- **Test runner errors** — baseline tests must pass before the
  mission starts. Fix that in a separate mission.
- **Scope creep** — worker touches files not listed. Garfield catches
  this. Either expand the mission via /draft or revert the extra
  changes.

## After the worker finishes

Run the reviewer (if your fleet has one):

```
claude --agent garfield --model opus --dangerously-skip-permissions
```

Or read `git log` and `git diff` yourself to verify.
