---
name: notebooklm-prep
description: >-
  Prepare a tailored NotebookLM audio overview for a specific listener — curate sources and write the customization prompt. Drives NotebookLM directly via MCP when available, or produces paste-ready artifacts.
when_to_use: >-
  Use when the user wants to build fluency in a domain quickly via audio — interview prep, client engagement prep, new-role onboarding, helping a friend learn, or any case where they want a podcast-style audio overview tailored to their existing knowledge. Triggers include NotebookLM, audio overview, podcast prep, interview prep, help me learn X for [meeting/role/topic], help [person] get up to speed on Y.
status: active
tags: [skill]
updated: 2026-05-07
---

# notebooklm-prep

Author a tailored NotebookLM audio overview for a specific listener.
Claude curates sources and writes the customization prompt;
NotebookLM generates the audio. The technique works because Claude
excels at exactly what NotebookLM needs help with: searching broadly
to identify high-quality sources, and writing highly specific prompts
that encode implicit knowledge about the listener.

## Modes

- **Direct mode** — when the notebooklm MCP server is connected and
  tools like `notebook_create`, `notebook_add_url`,
  `audio_overview_create` are available. Claude creates the
  notebook, adds sources, and generates the audio end-to-end.
- **Paste mode** — when the MCP isn't connected. Claude produces two
  artifacts (curated source list and customization prompt) for the
  user to paste into NotebookLM manually.

Detect mode by checking whether the notebook tools are available. If
yes, prefer direct mode. If no, fall back to paste mode without
apology.

## The two universal steps

### 1. Build the listener profile

If the user hasn't given the full picture, ask before searching. The
more you know, the better the output. Probe for:

- **Professional background** — what they do, expertise, adjacent
  knowledge they can draw on
- **Existing knowledge of the topic** — critical, so the audio doesn't
  waste time on basics they'll find patronizing
- **The goal** — interview, client conversation, new role, personal
  learning, helping someone else
- **Specific topics or areas of focus**
- **Tone preference** — study session, knowledgeable friend, senior
  colleague onboarding

Don't proceed until the profile is concrete. Specificity compounds
nonlinearly — every detail in the listener profile makes the output
meaningfully better.

### 2. Curate the sources

Use `web_search` to find candidates. Apply editorial judgment:

- **Layered authority** — mix official/authoritative (docs, specs,
  regulatory text) with practitioner content (blogs, tutorials,
  case studies). Officials give NotebookLM accurate facts;
  practitioners give it concrete examples.
- **Topical coverage** — sources collectively cover the topics;
  individual sources don't need to cover everything.
- **Quality filtering** — exclude SEO listicles, thin content,
  sources with sales agendas conflicting with listener interests,
  outdated material.
- **Recency** — for fast-moving topics, prefer the last 3–6 months.

Aim for 10–25 sources. NotebookLM caps at ~30. More for broad
multi-topic sessions; fewer for tightly focused ones. Every source
earns its place — don't fill quota with weak picks.

## Step 3 — Write the customization prompt

The customization prompt is where the magic happens. A good prompt:

- **Opens with who the listener is and what they already know**
- **Specifies topics to cover and how to weave them together**
- **Defines the tone** specifically ("knowledgeable friend explaining
  over coffee," "senior colleague onboarding someone in their first
  week," "practical study session")
- **Calls out what to spend MORE time on** — practical implications,
  decision frameworks, common-misconception rebuttals
- **Calls out what to spend LESS time on** — definitions, history,
  abstract theory
- **Specifies depth and length** — "aim for the longer end"
- **Notes common misconceptions** the listener should be inoculated
  against

## Step 4a — Direct mode delivery

1. `notebook_create` — descriptive title
2. `notebook_add_url` — one call per source URL. NotebookLM may
   fail to import some (paywalls, JS-heavy pages); track failures.
3. `notebook_get` (optional) — verify imports succeeded.
4. `audio_overview_create` — pass the customization prompt.
5. Poll for ready, then return notebook URL and audio URL.

If the first generation is off, the user describes what's wrong and
Claude regenerates with a refined prompt. The notebook itself is
reused; only the audio overview is regenerated.

## Step 4b — Paste mode delivery

When the MCP isn't connected, present two artifacts:

- "Here are the sources — paste into NotebookLM's web import:" →
  URLs separated by single spaces (no bullets, no commentary)
- "Here's the customization prompt — paste into the audio overview's
  customize prompt field:" → the full prompt text

## Pitfalls

- **Don't dump 30 unfocused sources.** Quality > quantity.
- **Don't write a vague prompt.** Specificity compounds nonlinearly.
- **Don't skip the listener profile.** Without it, the prompt has
  nothing distinctive to encode.
- **NotebookLM can't always import every URL.** Paywalled, JS-heavy,
  some doc sites may fail.
- **This produces fluency, not expertise.** Pair with a follow-up
  Claude chat for the user to test understanding.
- **Audio is one-way.** Mention this — the user can't ask follow-up
  questions during a podcast.
- **Don't auto-publish.** Anything user-facing or shared (renaming,
  deleting old notebooks, sharing URLs externally) needs explicit
  user confirmation.
