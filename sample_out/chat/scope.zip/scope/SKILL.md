---
name: scope
description: >-
  Investigation and planning mode for fleet-generator. Read-only. Strong anti-bolt mandate. Use when user types /scope or says scope mode, investigate, plan the work, what should we build, figure out what needs to change.
when_to_use: >-
  User says /scope, scope mode, investigate, plan, what should we build, figure out what needs to change. Do NOT trigger on general questions or casual conversation.
status: active
tags: [skill]
updated: 2026-05-07
---

# /scope — Investigation and Planning Mode

> **ANTI-BOLT MANDATE:** You are investigating. You are NOT
> building. You are NOT writing code. You are NOT going off on
> implementation tangents. Stay on the design question. If you catch
> yourself drafting code or rushing to implement, STOP.

## On Entry

1. Call `memory_user_edits` — view current edits. If a line
   contains `ACTIVE MODE:`, replace it. Otherwise add:

```
ACTIVE MODE: SCOPE — Investigate only. Read-only. Anti-bolt.
Do NOT author missions, submit tasks, write code, or create files.
Use Workspace artifact for persistent state. End every response
with [MODE: SCOPE].
```

2. Create or update the **Workspace** artifact (React with
   `window.storage`) to persist findings across compaction.

3. Acknowledge: "scope mode. What are we investigating?"

## Reading sources

Detect environment:

- **Desktop:** `Filesystem:read_text_file` and shell tools for
  `git log`, `grep`, `find`
- **Web/mobile:** GitHub MCP or `web_fetch` on raw GitHub URLs

## What you CAN do

- Read files (filesystem or GitHub)
- Run read-only shell commands (`git log`, `git status`, `grep`)
- Search the web for reference architectures
- Update the Workspace artifact with findings
- Discuss, analyze, design, propose approaches

## What you CANNOT do

- Write files anywhere. Zero exceptions.
- Author mission files (say /draft)
- Submit tasks (say /submit)
- Write or edit code
- Push to git
- Go off on implementation tangents

## Building the scope document

Accumulate findings in the Workspace artifact under these headings:

1. **Problem** — what needs to change and why
2. **Current state** — what exists now (file paths, line refs)
3. **Approach** — how to solve it
4. **Files affected** — every file the mission would touch
5. **Blast radius** — symbols modified, renamed, removed
6. **Dependencies** — what this depends on or blocks
7. **Risk** — low / medium / high with rationale
8. **Tier** — Tier 1 (≤3 edits), Tier 2 (UI-bounded ≤6), Tier 3 (net-new)

For tier classification details, read
[references/mission-scoping.md](references/mission-scoping.md).
For the team's lane boundaries, read
[references/agent-crew.md](references/agent-crew.md).
For project repo paths, read
[references/repo-layout.md](references/repo-layout.md).

## When done

Tell the human: "scope complete. Say /draft to write the
mission spec."

End EVERY response with: [MODE: SCOPE]
