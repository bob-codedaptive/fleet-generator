---
name: scope
description: >-
  Investigation and planning mode for fleet-generator. Read-only: reads, asks and proposes; writes no code or files. Use when user types /scope or says scope mode, investigate, plan the work, what should we build, figure out what needs to change.
when_to_use: >-
  User says /scope, scope mode, investigate, plan, what should we build, figure out what needs to change. Not for general questions or casual conversation.
status: active
tags: [skill]
updated: 2026-11-12
---

# /scope — Investigation and Planning Mode

You are investigating and planning, not building. In this mode you read,
ask, and propose; you write no code and no files. The reason: a design
question answered with code skips the part where the human decides, and
the code then has to be unpicked when the design changes. If you notice
yourself drafting an implementation, turn it back into a proposal.

## On entry

1. Call `memory_user_edits` and view the current edits. If a line
   contains `ACTIVE MODE:`, replace it; otherwise add:

```
ACTIVE MODE: SCOPE — Investigate and plan. Read-only. No missions,
no submits, no code, no files. Findings go in the Workspace artifact.
End each response with [MODE: SCOPE].
```

2. Create or update the **Workspace** artifact (React with
   `window.storage`) so findings survive compaction.

3. Say in a line that you are in scope mode, and ask what we are
   investigating if the human has not said.

## Look before you answer

Read broadly before you propose: the files the question names, the ones
that call them or are called by them, the recent history of those files,
and the docs that govern them, including ones the question does not
mention. A proposal built on the two files named in the question misses
the third file that breaks.

- **Desktop:** `Filesystem:read_text_file` and shell tools for
  `git log`, `grep`, `find`
- **Web or mobile:** GitHub MCP, or `web_fetch` on raw GitHub URLs

## What needs nobody's go-ahead

Reading any file in the project's repos; read-only shell commands
(`git log`, `git status`, `git diff`, `grep`, `find`); searching the
web for reference designs; updating the Workspace artifact.

## What waits for another mode

- Writing or editing files, code or missions: /draft writes the
  mission, and the worker writes the code
- Submitting work: /submit
- Pushing to git: the human's call

## The scope document

Keep findings in the Workspace artifact under these headings:

1. **Problem**: what needs to change and why
2. **Current state**: what exists now, with file:line references
3. **Approach**: how to solve it, with the options you weighed and why
   you recommend one
4. **Files affected**: every file the mission would touch
5. **Blast radius**: symbols modified, renamed, removed
6. **Dependencies**: what this depends on or blocks
7. **Risk**: low, medium or high, with the reason
8. **Tier**: Tier 1 (3 edits or fewer), Tier 2 (UI-bounded, 6 or fewer),
   Tier 3 (net-new)

For tier details, read
[references/mission-scoping.md](references/mission-scoping.md).
For the team's lanes, read
[references/agent-crew.md](references/agent-crew.md).
For repo paths, read
[references/repo-layout.md](references/repo-layout.md).

## Each turn

Answer what was asked in full in this turn. Ask a question only when its
answer changes the scope, and put it at the end with your recommended
answer. Mark what you read in the code as observed and what you infer
from it as inferred.

## When done

Close with a short recap that stands on its own: the problem, the
recommended approach, the open questions. Then: "scope complete. Say
/draft to write the mission."

End each response with [MODE: SCOPE], so the mode survives a long
conversation.
