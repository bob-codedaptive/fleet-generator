# Crew on fleet-generator

The human decides everything important. The agents enabled in this
fleet:

| Agent | Role | Model | Writes |
|---|---|---|---|
| Hobbes (`hobbes`) | Orchestrator | Claude Opus 5.5, medium | yes |
| Bilby (`bilby`) | Coordinator | Claude Opus 5.5, medium | yes |
| Woodstock (`woodstock`) | Code Worker | Claude Opus 5.5, medium | yes |
| Snoopy (`snoopy`) | Pre-flight Scanner | Claude Haiku 5.5, medium | read-only |
| Marvin (`marvin`) | Post-flight Inspector | Claude Haiku 5.5, medium | read-only |
| Agatha (`agatha`) | Submission Gate | Claude Haiku 5.5, high | read-only |
| Calvin (`calvin`) | Architect | Claude Opus 5.5, medium | read-only |
| Ace (`ace`) | Last-resort Coder | Claude Opus 5.5, xhigh | yes |
| Ada (`ada`) | Numeric Specialist | Claude Opus 5.5, xhigh | read-only |
| Sherlock (`sherlock`) | Root-cause Investigator | Claude Opus 5.5, medium | read-only |
| Escher (`escher`) | Visual Consistency Reviewer | Claude Sonnet 5.5, medium | read-only |
| Linus (`linus`) | Doc Writer | Claude Sonnet 5.5, medium | yes |
| Dogbert (`dogbert`) | Security Reviewer | Claude Haiku 5.5, high | read-only |
| Cathy (`cathy`) | Accessibility Reviewer | Claude Sonnet 5.5, medium | read-only |
| Odie (`odie`) | Performance Reviewer | Claude Sonnet 5.5, medium | read-only |

## Lanes

- Hobbes scopes, drafts and writes missions; it writes no code and
  does not push
- Woodstock implements missions and commits; it does not author
  missions or doctrine
- Read-only agents report; they modify nothing

## Standard flow

1. The human describes a need
2. Hobbes investigates (/scope) and drafts the mission (/draft)
3. The human launches Woodstock with it (/submit)
4. Woodstock runs pre-flight, implements, runs the tests once, and
   starts post-flight review
5. Specialist reviewers run when their triggers fire
6. The human reviews and merges
