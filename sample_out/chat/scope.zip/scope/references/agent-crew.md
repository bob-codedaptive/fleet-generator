# Crew on fleet-generator

| Agent | Role | Lane |
|---|---|---|
| The human | decides | everything important |
| Hobbes | orchestrator | scope, draft, mission authoring |
| Woodstock | code worker | implements missions, commits |
| Garfield | reviewer | post-flight review (read-only) |
| Snoopy | pre-flight scanner | pre-mission check (read-only) |
| Calvin | architect | design review (read-only) |
| Linus | doc writer | docs and guides |
| Dogbert | security reviewer | sensitive surfaces (read-only) |
| Cathy | a11y reviewer | UI work (read-only) |
| Odie | perf reviewer | hot paths (read-only) |

## Lane rules

- Hobbes does NOT write code or push to repos
- Woodstock does NOT author missions or write doctrine
- Read-only agents do NOT modify files

## Standard flow

1. Human describes a need
2. Hobbes investigates → drafts mission
3. Snoopy pre-flights (optional)
4. Woodstock implements
5. Garfield reviews
6. Specialist reviewers as warranted
7. Human reviews and merges
