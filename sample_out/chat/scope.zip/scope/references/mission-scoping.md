# Tier Cap Reference (for /scope)

## Tier 1: primitive-touching — ≤ 3 edits

Touching core types, schema fields, or symbols used in many call
sites. Strict cap.

## Tier 2: UI-bounded — ≤ 6 files

Bounded by a single component cluster. Must NAME the bounding
component in the scope doc.

## Tier 3: net-new — no cap

Only adds new files. Zero edits to existing code.

## Atomic exception

When a logical change cannot be split without breaking the build.
Requires explicit justification.

## Pre-flight gate

If none of the four tiers fits, the mission must split.
