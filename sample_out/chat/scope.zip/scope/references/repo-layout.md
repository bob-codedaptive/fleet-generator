# Repo Layout for fleet-generator

This file is generated from your wizard inputs. The orchestrator
reads it to know where things live.

| Repo | Branch | Path |
|---|---|---|
| fleet-generator | main | ~/devlop/forge/fleet-generator |


## Conventions

- Agent system files live in each repo's `.claude/`
- Mission files: paste directly into Claude CLI when launching Woodstock
- Branch names use kebab-case
- One agent works on a given file at a time
